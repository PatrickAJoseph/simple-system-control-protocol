################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../common/lib_opt/ctrl_opt_adaptivity.c \
../common/lib_opt/ctrl_opt_adv_conn.c \
../common/lib_opt/ctrl_opt_adv_nconn.c \
../common/lib_opt/ctrl_opt_ae.c \
../common/lib_opt/ctrl_opt_ble_health.c \
../common/lib_opt/ctrl_opt_cm.c \
../common/lib_opt/ctrl_opt_connectable.c \
../common/lib_opt/ctrl_opt_connection_handover.c \
../common/lib_opt/ctrl_opt_cs.c \
../common/lib_opt/ctrl_opt_cs_test.c \
../common/lib_opt/ctrl_opt_dmm.c \
../common/lib_opt/ctrl_opt_dmm_dynamic_priority.c \
../common/lib_opt/ctrl_opt_ext_vendor_specific_cmd.c \
../common/lib_opt/ctrl_opt_health_check.c \
../common/lib_opt/ctrl_opt_initiator.c \
../common/lib_opt/ctrl_opt_legacy_cmd.c \
../common/lib_opt/ctrl_opt_padv.c \
../common/lib_opt/ctrl_opt_past_receiver.c \
../common/lib_opt/ctrl_opt_past_sender.c \
../common/lib_opt/ctrl_opt_pawr_scan.c \
../common/lib_opt/ctrl_opt_power_control.c \
../common/lib_opt/ctrl_opt_pscan.c \
../common/lib_opt/ctrl_opt_rssi_monitor.c \
../common/lib_opt/ctrl_opt_scanner.c \
../common/lib_opt/ctrl_opt_vendor_specific_cmd.c \
../common/lib_opt/host_opt_gap_bond_mgr.c 

C_DEPS += \
./common/lib_opt/ctrl_opt_adaptivity.d \
./common/lib_opt/ctrl_opt_adv_conn.d \
./common/lib_opt/ctrl_opt_adv_nconn.d \
./common/lib_opt/ctrl_opt_ae.d \
./common/lib_opt/ctrl_opt_ble_health.d \
./common/lib_opt/ctrl_opt_cm.d \
./common/lib_opt/ctrl_opt_connectable.d \
./common/lib_opt/ctrl_opt_connection_handover.d \
./common/lib_opt/ctrl_opt_cs.d \
./common/lib_opt/ctrl_opt_cs_test.d \
./common/lib_opt/ctrl_opt_dmm.d \
./common/lib_opt/ctrl_opt_dmm_dynamic_priority.d \
./common/lib_opt/ctrl_opt_ext_vendor_specific_cmd.d \
./common/lib_opt/ctrl_opt_health_check.d \
./common/lib_opt/ctrl_opt_initiator.d \
./common/lib_opt/ctrl_opt_legacy_cmd.d \
./common/lib_opt/ctrl_opt_padv.d \
./common/lib_opt/ctrl_opt_past_receiver.d \
./common/lib_opt/ctrl_opt_past_sender.d \
./common/lib_opt/ctrl_opt_pawr_scan.d \
./common/lib_opt/ctrl_opt_power_control.d \
./common/lib_opt/ctrl_opt_pscan.d \
./common/lib_opt/ctrl_opt_rssi_monitor.d \
./common/lib_opt/ctrl_opt_scanner.d \
./common/lib_opt/ctrl_opt_vendor_specific_cmd.d \
./common/lib_opt/host_opt_gap_bond_mgr.d 

OBJS += \
./common/lib_opt/ctrl_opt_adaptivity.o \
./common/lib_opt/ctrl_opt_adv_conn.o \
./common/lib_opt/ctrl_opt_adv_nconn.o \
./common/lib_opt/ctrl_opt_ae.o \
./common/lib_opt/ctrl_opt_ble_health.o \
./common/lib_opt/ctrl_opt_cm.o \
./common/lib_opt/ctrl_opt_connectable.o \
./common/lib_opt/ctrl_opt_connection_handover.o \
./common/lib_opt/ctrl_opt_cs.o \
./common/lib_opt/ctrl_opt_cs_test.o \
./common/lib_opt/ctrl_opt_dmm.o \
./common/lib_opt/ctrl_opt_dmm_dynamic_priority.o \
./common/lib_opt/ctrl_opt_ext_vendor_specific_cmd.o \
./common/lib_opt/ctrl_opt_health_check.o \
./common/lib_opt/ctrl_opt_initiator.o \
./common/lib_opt/ctrl_opt_legacy_cmd.o \
./common/lib_opt/ctrl_opt_padv.o \
./common/lib_opt/ctrl_opt_past_receiver.o \
./common/lib_opt/ctrl_opt_past_sender.o \
./common/lib_opt/ctrl_opt_pawr_scan.o \
./common/lib_opt/ctrl_opt_power_control.o \
./common/lib_opt/ctrl_opt_pscan.o \
./common/lib_opt/ctrl_opt_rssi_monitor.o \
./common/lib_opt/ctrl_opt_scanner.o \
./common/lib_opt/ctrl_opt_vendor_specific_cmd.o \
./common/lib_opt/host_opt_gap_bond_mgr.o 

OBJS__QUOTED += \
"common\lib_opt\ctrl_opt_adaptivity.o" \
"common\lib_opt\ctrl_opt_adv_conn.o" \
"common\lib_opt\ctrl_opt_adv_nconn.o" \
"common\lib_opt\ctrl_opt_ae.o" \
"common\lib_opt\ctrl_opt_ble_health.o" \
"common\lib_opt\ctrl_opt_cm.o" \
"common\lib_opt\ctrl_opt_connectable.o" \
"common\lib_opt\ctrl_opt_connection_handover.o" \
"common\lib_opt\ctrl_opt_cs.o" \
"common\lib_opt\ctrl_opt_cs_test.o" \
"common\lib_opt\ctrl_opt_dmm.o" \
"common\lib_opt\ctrl_opt_dmm_dynamic_priority.o" \
"common\lib_opt\ctrl_opt_ext_vendor_specific_cmd.o" \
"common\lib_opt\ctrl_opt_health_check.o" \
"common\lib_opt\ctrl_opt_initiator.o" \
"common\lib_opt\ctrl_opt_legacy_cmd.o" \
"common\lib_opt\ctrl_opt_padv.o" \
"common\lib_opt\ctrl_opt_past_receiver.o" \
"common\lib_opt\ctrl_opt_past_sender.o" \
"common\lib_opt\ctrl_opt_pawr_scan.o" \
"common\lib_opt\ctrl_opt_power_control.o" \
"common\lib_opt\ctrl_opt_pscan.o" \
"common\lib_opt\ctrl_opt_rssi_monitor.o" \
"common\lib_opt\ctrl_opt_scanner.o" \
"common\lib_opt\ctrl_opt_vendor_specific_cmd.o" \
"common\lib_opt\host_opt_gap_bond_mgr.o" 

C_DEPS__QUOTED += \
"common\lib_opt\ctrl_opt_adaptivity.d" \
"common\lib_opt\ctrl_opt_adv_conn.d" \
"common\lib_opt\ctrl_opt_adv_nconn.d" \
"common\lib_opt\ctrl_opt_ae.d" \
"common\lib_opt\ctrl_opt_ble_health.d" \
"common\lib_opt\ctrl_opt_cm.d" \
"common\lib_opt\ctrl_opt_connectable.d" \
"common\lib_opt\ctrl_opt_connection_handover.d" \
"common\lib_opt\ctrl_opt_cs.d" \
"common\lib_opt\ctrl_opt_cs_test.d" \
"common\lib_opt\ctrl_opt_dmm.d" \
"common\lib_opt\ctrl_opt_dmm_dynamic_priority.d" \
"common\lib_opt\ctrl_opt_ext_vendor_specific_cmd.d" \
"common\lib_opt\ctrl_opt_health_check.d" \
"common\lib_opt\ctrl_opt_initiator.d" \
"common\lib_opt\ctrl_opt_legacy_cmd.d" \
"common\lib_opt\ctrl_opt_padv.d" \
"common\lib_opt\ctrl_opt_past_receiver.d" \
"common\lib_opt\ctrl_opt_past_sender.d" \
"common\lib_opt\ctrl_opt_pawr_scan.d" \
"common\lib_opt\ctrl_opt_power_control.d" \
"common\lib_opt\ctrl_opt_pscan.d" \
"common\lib_opt\ctrl_opt_rssi_monitor.d" \
"common\lib_opt\ctrl_opt_scanner.d" \
"common\lib_opt\ctrl_opt_vendor_specific_cmd.d" \
"common\lib_opt\host_opt_gap_bond_mgr.d" 

C_SRCS__QUOTED += \
"../common/lib_opt/ctrl_opt_adaptivity.c" \
"../common/lib_opt/ctrl_opt_adv_conn.c" \
"../common/lib_opt/ctrl_opt_adv_nconn.c" \
"../common/lib_opt/ctrl_opt_ae.c" \
"../common/lib_opt/ctrl_opt_ble_health.c" \
"../common/lib_opt/ctrl_opt_cm.c" \
"../common/lib_opt/ctrl_opt_connectable.c" \
"../common/lib_opt/ctrl_opt_connection_handover.c" \
"../common/lib_opt/ctrl_opt_cs.c" \
"../common/lib_opt/ctrl_opt_cs_test.c" \
"../common/lib_opt/ctrl_opt_dmm.c" \
"../common/lib_opt/ctrl_opt_dmm_dynamic_priority.c" \
"../common/lib_opt/ctrl_opt_ext_vendor_specific_cmd.c" \
"../common/lib_opt/ctrl_opt_health_check.c" \
"../common/lib_opt/ctrl_opt_initiator.c" \
"../common/lib_opt/ctrl_opt_legacy_cmd.c" \
"../common/lib_opt/ctrl_opt_padv.c" \
"../common/lib_opt/ctrl_opt_past_receiver.c" \
"../common/lib_opt/ctrl_opt_past_sender.c" \
"../common/lib_opt/ctrl_opt_pawr_scan.c" \
"../common/lib_opt/ctrl_opt_power_control.c" \
"../common/lib_opt/ctrl_opt_pscan.c" \
"../common/lib_opt/ctrl_opt_rssi_monitor.c" \
"../common/lib_opt/ctrl_opt_scanner.c" \
"../common/lib_opt/ctrl_opt_vendor_specific_cmd.c" \
"../common/lib_opt/host_opt_gap_bond_mgr.c" 


