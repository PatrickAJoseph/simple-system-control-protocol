################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
build-1875731377: ../basic_ble.syscfg
	@echo 'Building file: "$<"'
	@echo 'Invoking: SysConfig'
	"C:/ti/sysconfig_1.23.2/sysconfig_cli.bat" -s "C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/.metadata/product.json" --script "C:/Users/hp/workspace_ccstheia/sscp_ble/basic_ble.syscfg" -o "syscfg" --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/ti_ble_config.h: build-1875731377 ../basic_ble.syscfg
syscfg/ti_ble_config.c: build-1875731377
syscfg/ti_devices_config.c: build-1875731377
syscfg/ti_radio_config.c: build-1875731377
syscfg/ti_radio_config.h: build-1875731377
syscfg/ti_drivers_config.c: build-1875731377
syscfg/ti_drivers_config.h: build-1875731377
syscfg/ti_utils_build_linker.cmd.genlibs: build-1875731377
syscfg/ti_utils_build_linker.cmd.genmap: build-1875731377
syscfg/ti_utils_build_compiler.opt: build-1875731377
syscfg/syscfg_c.rov.xs: build-1875731377
syscfg/FreeRTOSConfig.h: build-1875731377
syscfg/ti_freertos_config.c: build-1875731377
syscfg/ti_freertos_portable_config.c: build-1875731377
syscfg: build-1875731377

syscfg/%.o: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"C:/ti/ccs2031/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/ble/stack_util/config/build_components.opt" @"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/ble/stack_util/config/factory_config.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -Oz -I"C:/Users/hp/workspace_ccstheia/sscp_ble/sscp/inc" -I"C:/Users/hp/workspace_ccstheia/sscp_ble" -I"C:/Users/hp/workspace_ccstheia/sscp_ble/Release" -I"C:/Users/hp/workspace_ccstheia/sscp_ble/app" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/common/cc26xx" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/posix/ticlang" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/portable/GCC/ARM_CM0" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/kernel/freertos" -DICALL_NO_APP_EVENTS -DCC23X0 -DNVOCMP_NWSAMEITEM=1 -DNVOCMP_NVPAGES=6 -DFREERTOS -DNVOCMP_POSIX_MUTEX -gdwarf-3 -Wunused-function -ffunction-sections -MMD -MP -MF"syscfg/$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/hp/workspace_ccstheia/sscp_ble/Release/syscfg" -std=c99 $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"C:/ti/ccs2031/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/ble/stack_util/config/build_components.opt" @"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/ble/stack_util/config/factory_config.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -Oz -I"C:/Users/hp/workspace_ccstheia/sscp_ble/sscp/inc" -I"C:/Users/hp/workspace_ccstheia/sscp_ble" -I"C:/Users/hp/workspace_ccstheia/sscp_ble/Release" -I"C:/Users/hp/workspace_ccstheia/sscp_ble/app" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/common/cc26xx" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/posix/ticlang" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/portable/GCC/ARM_CM0" -I"C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/kernel/freertos" -DICALL_NO_APP_EVENTS -DCC23X0 -DNVOCMP_NWSAMEITEM=1 -DNVOCMP_NVPAGES=6 -DFREERTOS -DNVOCMP_POSIX_MUTEX -gdwarf-3 -Wunused-function -ffunction-sections -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/hp/workspace_ccstheia/sscp_ble/Release/syscfg" -std=c99 $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


