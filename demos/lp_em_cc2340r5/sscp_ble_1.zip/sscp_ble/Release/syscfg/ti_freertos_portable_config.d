# FIXED

syscfg/ti_freertos_portable_config.o: \
 syscfg/ti_freertos_portable_config.c syscfg/FreeRTOSConfig.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/posix/freertos/PTLS.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/portable/GCC/ARM_CM0/port.c \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/FreeRTOS.h \
 syscfg/FreeRTOSConfig.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/projdefs.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/portable.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/deprecated_definitions.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/portable/GCC/ARM_CM0/portmacro.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/mpu_wrappers.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/task.h \
 C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/list.h
syscfg/FreeRTOSConfig.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/ti/posix/freertos/PTLS.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/portable/GCC/ARM_CM0/port.c:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/FreeRTOS.h:
syscfg/FreeRTOSConfig.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/projdefs.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/portable.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/deprecated_definitions.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/portable/GCC/ARM_CM0/portmacro.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/mpu_wrappers.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/task.h:
C:/ti/simplelink_lowpower_f3_sdk_9_14_01_16/source/third_party/freertos/include/list.h:
